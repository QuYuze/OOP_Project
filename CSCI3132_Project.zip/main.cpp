#include <iostream>
#include "Character.h"

int game();

int main() {
    game();
    return 0;


}

int game(){
    cout << "your name?" << endl;
    string name;
    cin >> name;
    Player p = Player(name);
    p.appear();
/*
    bool wishToPlay = true;
    while(wishToPlay = true){

       wishToPlay = false;
    }
*/
    Monster  m = Monster(p.getLevel());
    int flag = 1;
    while(flag != 0){
        p.attack(m);
        cout << m.getName() << " now have " << m.getHP() << " HP!" << endl;
        cout << endl;
        if(m.getHP()<=0){
            cout<< p.getName() << " killed the " << m.getName() << " !" << endl;
            cout << "You are victorius!" << endl;
            p.addExp(m.getBonus());
            flag = 0;

        }else{
            m.attack(p);
            cout << p.getName() << " now have " << p.getHP() << " HP..." << endl;
            cout << endl;
            if(p.getHP()<=0){
                cout << "Your are defeated..." << endl;
                flag = 0;
            }
        }
    }
    return 0;
}